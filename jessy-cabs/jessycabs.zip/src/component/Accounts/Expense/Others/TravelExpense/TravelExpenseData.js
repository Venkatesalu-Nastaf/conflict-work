// TripType

export const TripType = [
    {
        Option: "One-Way-Trip",
        optionvalue: "OneWayTrip",
    },
  
    {
        Option: "Round-Trip",
        optionvalue: "Roundtrip",
    },
    
    {
        Option: "Multi-City-Trip",
        optionvalue: "MultiCityTrip",
    },
  ];