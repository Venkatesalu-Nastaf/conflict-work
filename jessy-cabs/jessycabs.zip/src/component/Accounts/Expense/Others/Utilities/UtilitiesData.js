// UtilitiesType

export const UtilitiesType = [
    {
        Option: "Electricity Bill",
        optionvalue: "electricitybill",
    },
  
    {
        Option: "Gas Bill",
        optionvalue: "gasbill",
    },
    
    {
        Option: "Water Bill",
        optionvalue: "waterbill",
    },
    
    {
        Option: "Internet Bill",
        optionvalue: "internetbill",
    },
    
    {
        Option: "Telephone Bill",
        optionvalue: "telephonebill",
    },
    {
        Option: "Transport Bill",
        optionvalue: "transportbill",
    },
    {
        Option: "Tv Subscription / cable Bill",
        optionvalue: "tvsubscription",
    },
    
    {
        Option: "Trash Garbage Recycling",
        optionvalue: "trasgharbagerecycling",
    },
  ];