import React from 'react'

const ProfiteLoss = () => {
  return (
    <div>ProfiteLoss</div>
  )
}

export default ProfiteLoss