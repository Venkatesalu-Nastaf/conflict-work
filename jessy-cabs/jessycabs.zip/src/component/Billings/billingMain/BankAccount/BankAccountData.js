// AccountType
export const AccountType = [
    {
      Option: "Current Account",
      optionvalue: "CurrentAccount",
    },
    {
        Option: "Savings Account",
        optionvalue: "SavingsAccount",
      },
    {
      Option: "Demat Account",
      optionvalue: "DematAccount",
    },
    {
        Option: "Joint Account",
        optionvalue: "JointAccount",
      },
    {
      Option: "Public Provident Fund (PPF) Account",
      optionvalue: "PublicProvidentFund",
    },
    {
        Option: "Employees Provident Fund (EPF) Account",
        optionvalue: "EmployeesProvidentFund",
      },
  ];