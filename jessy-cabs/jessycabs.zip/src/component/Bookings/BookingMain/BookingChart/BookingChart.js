export const VehicleModel = [
    {
      carmodel: "20 SEATER BUS",
      carmodelvalue: "20SEATERBUS",
    },
    {
      carmodel: "45 SEATER BUS",
      carmodelvalue: "45SEATERBUS",
    },
    {
      carmodel: "ACCORD",
      carmodelvalue: "ACCORD",
    },
    {
      carmodel: "AMAZE",
      carmodelvalue: "AMAZE",
    },
    {
      carmodel: "AUDI",
      carmodelvalue: "AUDI",
    },
    {
      carmodel: "AUDI A6",
      carmodelvalue: "AUDIA6",
    },
    {
      carmodel: "BALENO",
      carmodelvalue: "BALENO",
    },
    {
      carmodel: "BENZ E CLASS",
      carmodelvalue: "BENZECLASS",
    },
    {
      carmodel: "BENZ S CLASS",
      carmodelvalue: "BENZSCLASS",
    },
    {
      carmodel: "BIKE",
      carmodelvalue: "BIKE",
    },
    {
      carmodel: "BMW 5 SERIES",
      carmodelvalue: "BMW5SERIES",
    },
    {
      carmodel: "BMW 7 SERIES",
      carmodelvalue: "BMW7SERIES",
    },
    {
      carmodel: "BUS",
      carmodelvalue: "BUS",
    },
    {
      carmodel: "BUS - 20 SEATER",
      carmodelvalue: "BUS-20SEATER",
    },
    {
      carmodel: "CAMRY A/C",
      carmodelvalue: "CAMRYA/C",
    },
    {
      carmodel: "COROLLA A/C",
      carmodelvalue: "COROLLAA/C",
    },
    {
      carmodel: "COROLLA ALTIS A/C",
      carmodelvalue: "COROLLAALTISA/C",
    },
    {
      carmodel: "CRYSTA A/C",
      carmodelvalue: "CRYSTAA/C",
    },
    {
      carmodel: "DELUXE VAN",
      carmodelvalue: "DELUXEVAN",
    },
    {
      carmodel: "DZIRE A/C",
      carmodelvalue: "DZIREA/C",
    },
    {
      carmodel: "ERTIGA",
      carmodelvalue: "ERTIGA",
    },
    {
      carmodel: "ETIOS A/C",
      carmodelvalue: "ETIOSA/C",
    },
    {
      carmodel: "FIESTA A/C",
      carmodelvalue: "FIESTAA/C",
    },
    {
      carmodel: "FIGO A/C",
      carmodelvalue: "FIGOA/C",
    },
    {
      carmodel: "FORD ENDEAVOR A/C",
      carmodelvalue: "FORDENDEAVORA/C",
    },
    {
      carmodel: "FORD IKON A/C",
      carmodelvalue: "FORDIKONA/C",
    },
    {
      carmodel: "FORTUNER",
      carmodelvalue: "FORTUNER",
    },
    {
      carmodel: "HONDA CITY",
      carmodelvalue: "HONDACITY",
    },
    {
      carmodel: "HONDA CITY A/C",
      carmodelvalue: "HONDACITYA/C",
    },
    {
      carmodel: "HYUNDAI VERNA",
      carmodelvalue: "HYUNDAIVERNA",
    },
    {
      carmodel: "INDICA A/C",
      carmodelvalue: "INDICAA/C",
    },
    {
      carmodel: "INDICA NON A/C",
      carmodelvalue: "INDICANONA/C",
    },
    {
      carmodel: "INDIGO A/C",
      carmodelvalue: "INDIGOA/C",
    },
    {
      carmodel: "INNOVA A/C",
      carmodelvalue: "INNOVAA/C",
    },
    {
      carmodel: "ISUZU",
      carmodelvalue: "ISUZU",
    },
    {
      carmodel: "LOGAN",
      carmodelvalue: "LOGAN",
    },
    {
      carmodel: "MAHINDRA VAN",
      carmodelvalue: "MAHINDRAVAN",
    },
    {
      carmodel: "MERC VIANO A/C",
      carmodelvalue: "MERCVIANOA/C",
    },
    {
      carmodel: "MINI BUS",
      carmodelvalue: "MINIBUS",
    },
    {
      carmodel: "QUALIS",
      carmodelvalue: "QUALIS",
    },
    {
      carmodel: "RITZ",
      carmodelvalue: "RITZ",
    },
    {
      carmodel: "ROLLS ROYCE",
      carmodelvalue: "ROLLS-ROYCE",
    },
    {
      carmodel: "SADAN A/C",
      carmodelvalue: "SADANA/C",
    },
    {
      carmodel: "SUMO",
      carmodelvalue: "SUMO",
    },
    {
      carmodel: "SUNNY Car",
      carmodelvalue: "SUNNY-car",
    },
    {
      carmodel: "SWARAJ MAZDA",
      carmodelvalue: "SWARAJ-MAZDA",
    },
    {
      carmodel: 'SWARAJ MAZDA NON A/C',
      carmodelvalue: "SWARAJ-MAZDA-NON-A/C",
    },
    {
      carmodel: "TATA ACE",
      carmodelvalue: "TATA-ACE",
    },
    {
      carmodel: "TATA ARIA",
      carmodelvalue: "TATA-ARIA",
    },
    {
      carmodel: "TAVERA AC",
      carmodelvalue: "TAVERA-AC",
    },
    {
      carmodel: "TAVERA NON A/C",
      carmodelvalue: "TAVERA-NON-A/C",
    },
    {
      carmodel: "TEMPO 12 SEATER",
      carmodelvalue: "TEMPO-12-SEATER",
    },
    {
      carmodel: "TEMPO 14 SEATER",
      carmodelvalue: "TEMPO-14-SEATER",
    },
    {
      carmodel: "TEMPO 20 SEATER",
      carmodelvalue: "TEMPO-20-SEATER",
    },
    {
      carmodel: "TEMPO A/C",
      carmodelvalue: "TEMPO-A/C",
    },
    {
      carmodel: "TOURISTER VAN",
      carmodelvalue: "TOURISTER-VAN",
    },
    {
      carmodel: "TOYOTO COMMUTER",
      carmodelvalue: "TOYOT-COMMUTER",
    },
    {
      carmodel: "TOYOTO FORTUNER",
      carmodelvalue: "TOYOTO-FORTUNER",
    },
    {
      carmodel: "TRAVELLER",
      carmodelvalue: "TRAVELLER",
    },
    {
      carmodel: "TRAVELLER AC",
      carmodelvalue: "TRAVELLER-AC",
    },
    {
      carmodel: "TVS STAR SPORTTRAVELLER AC",
      carmodelvalue: "TVS-STAR-SPORT",
    },
    {
      carmodel: "TWO WHEELER",
      carmodelvalue: "TWO-WHEELER",
    },
    {
      carmodel: "VOLVO - 28 SHEET BUS",
      carmodelvalue: "VOLVO-28-SHEET-BUS",
    },
    {
      carmodel: "VOLVO - 40 SHEET BUS",
      carmodelvalue: "VOLVO-40-SHEET-BUS",
    },
    {
      carmodel: "VOLVO - BUS",
      carmodelvalue: "VOLVO-BUS",
    },
    {
      carmodel: "XCENT",
      carmodelvalue: "XCENT",
    },
    {
      carmodel: "XYLO A/C",
      carmodelvalue: "XYLO-A/C",
    },
  ];