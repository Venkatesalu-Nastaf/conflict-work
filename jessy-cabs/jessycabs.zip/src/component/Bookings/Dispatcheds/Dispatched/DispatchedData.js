export const Department = [
  {
    option: "All Station",
    optionvalue: "allstation",
  },
  {
    option: "Ahmedabad",
    optionvalue: "ahmedabad",
  },
  {
    option: "Bangalore",
    optionvalue: "bangalore",
  },
  {
    option: "Chennai",
    optionvalue: "chennai",
  },
  {
    option: "Coimbatore",
    optionvalue: "coimbatore",
  },
  {
    option: "Delhi",
    optionvalue: "delhi",
  },
  {
    option: "ERODE",
    optionvalue: "ERODE",
  },
  {
    option: "GOA",
    optionvalue: "goa",
  },
  {
    option: "Hyderabad",
    optionvalue: "hyderabad",
  },
  {
    option: "INDORE",
    optionvalue: "INDORE",
  },
  {
    option: "Jaipur",
    optionvalue: "jaipur",
  },
  {
    option: "Kerala",
    optionvalue: "kerala",
  },
  {
    option: "Kolkata",
    optionvalue: "kolkata",
  },
  {
    option: "Lucknow",
    optionvalue: "lucknow",
  },
  {
    option: "Madurai",
    optionvalue: "madurai",
  },
  {
    option: "Mangalore",
    optionvalue: "mangalore",
  },
  {
    option: "Mumbai",
    optionvalue: "mumbai",
  },
  {
    option: "Nagpur",
    optionvalue: "nagpur",
  },
  {
    option: "New One",
    optionvalue: "newone",
  },
  {
    option: "Pune",
    optionvalue: "pune",
  },
  {
    option: "Tiruchi",
    optionvalue: "tiruchi",
  },
  {
    option: "Vijayawada",
    optionvalue: "vijayawada",
  },
];