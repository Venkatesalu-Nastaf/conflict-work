// Recent Update Card Data
export const UpdatesData = [
  {
    id: 1,
    // img: img1,
    name: "Mani",
    noti: "has achived 60% of today target",
    time: "25 seconds ago",
  },
  {
    id: 2,
    // img: img2,
    name: "Ravi",
    noti: "has achived 30% of today target.",
    time: "30 minutes ago",
  },
  {
    id: 3,
    // img: img3,
    name: "Thiru",
    noti: "has achived 50% of today target",
    time: "2 hours ago",
  },
];
