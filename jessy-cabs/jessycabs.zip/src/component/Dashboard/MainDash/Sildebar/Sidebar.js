
export const Sidebardata = [
  {
    heading: "Dashboard",
    key: "/home/dashboard",
  },
  {
    heading: "Booking",
    key: "/home/bookings/booking",
  },
  {
    heading: "Billing",
    key: "/home/billing/billing",
  },
  {
    heading: "Registration",
    key: "/home/registration/customer",
  },
  {
    heading: "Settings",
    key: "/home/settings/usercreation",
  },
  {
    heading: "Info",
    key: "/home/info/ratetype",
  },
  {
    heading: "User",
    key: "/home/usersettings/usersetting",
  },

];