export const StationName = [
    {
        Option: "-- Select State --",
        optionvalue: "",
    },
    {
        Option: "Andhra Pradesh",
        optionvalue: "andhra-pradesh",
    },
    {
        Option: "Arunachal Pradesh",
        optionvalue: "arunachal-pradesh",
    },
    {
        Option: "Assam",
        optionvalue: "assam",
    },
    {
        Option: "Bihar",
        optionvalue: "bihar",
    },
    {
        Option: "Chandigarh",
        optionvalue: "chandigarh",
    },
    {
        Option: "Chhattisgarh",
        optionvalue: "chhattisgarh",
    },
    {
        Option: "Dadra and Nagar Haveli",
        optionvalue: "dadra-nagar-haveli",
    },
    {
        Option: "Daman and Diu",
        optionvalue: "daman-diu",
    },
    {
        Option: "Delhi",
        optionvalue: "delhi",
    },
    {
        Option: "Goa",
        optionvalue: "goa",
    },
    {
        Option: "Gujarat",
        optionvalue: "gujarat",
    },
    {
        Option: "Haryana",
        optionvalue: "haryana",
    },
    {
        Option: "Himachal Pradesh",
        optionvalue: "himachal-pradesh",
    },
    {
        Option: "Jammu and Kashmir",
        optionvalue: "jammu-kashmir",
    },
    {
        Option: "Jharkhand",
        optionvalue: "jharkhand",
    },
    {
        Option: "Karnataka",
        optionvalue: "karnataka",
    },
    {
        Option: "Kerala",
        optionvalue: "kerala",
    },
    {
        Option: "Lakshadweep",
        optionvalue: "lakshadweep",
    },
    {
        Option: "Madhya Pradesh",
        optionvalue: "madhya-pradesh",
    },
    {
        Option: "Maharashtra",
        optionvalue: "maharashtra",
    },
    {
        Option: "Manipur",
        optionvalue: "manipur",
    },
    {
        Option: "Meghalaya",
        optionvalue: "meghalaya",
    },
    {
        Option: "Mizoram",
        optionvalue: "mizoram",
    },
    {
        Option: "Nagaland",
        optionvalue: "nagaland",
    },
    {
        Option: "Odisha",
        optionvalue: "odisha",
    },
    {
        Option: "Puducherry",
        optionvalue: "puducherry",
    },
    {
        Option: "Punjab",
        optionvalue: "punjab",
    },
    {
        Option: "Rajasthan",
        optionvalue: "rajasthan",
    },
    {
        Option: "Sikkim",
        optionvalue: "sikkim",
    },
    {
        Option: "Tamil Nadu",
        optionvalue: "tamil-nadu",
    },
    {
        Option: "Telangana",
        optionvalue: "telangana",
    },
    {
        Option: "Tripura",
        optionvalue: "tripura",
    },
    {
        Option: "Uttar Pradesh",
        optionvalue: "uttar-pradesh",
    },
    {
        Option: "Uttarakhand",
        optionvalue: "uttarakhand",
    },
    {
        Option: "West Bengal",
        optionvalue: "west-bengal",
    },
]