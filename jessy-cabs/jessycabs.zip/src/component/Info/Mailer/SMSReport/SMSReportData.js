// Status

export const Status = [
    {
        Option: "All",
        optionvalue: "All",
    },
    {
        Option: "Waiting",
        optionvalue: "Waiting",
    },
    {
        Option: "Sent",
        optionvalue: "Sent",
    },
    {
        Option: "Failed",
        optionvalue: "Failed",
    },
    {
        Option: "Deleted",
        optionvalue: "Deleted",
    },
];