// Under Group
export const Undergroup = [
    {
      Option: "ADVANCE",
      optionvalue: "advance",
    },
    {
      Option: "ASSETS",
      optionvalue: "assets",
    },
    {
      Option: "Bank Accounts",
      optionvalue: "bank_accounts",
    },
    {
      Option: "CASH BOOK GROUP",
      optionvalue: "cash_book_group",
    },
    {
      Option: "CURRENT ASSETS",
      optionvalue: "current_assets",
    },
    {
      Option: "DHAN LXMI BANK",
      optionvalue: "dhan_lxmi_bank",
    },
    {
      Option: "Direct Expenses",
      optionvalue: "direct_expenses",
    },
    {
      Option: "DISCOUNT ALLOWED",
      optionvalue: "discount_allowed",
    },
    {
      Option: "Duties & Taxes",
      optionvalue: "duties_taxes",
    },
    {
      Option: " EXPENSE",
      optionvalue: "expense",
    },
    {
      Option: "FIXED ASSETS",
      optionvalue: "fixedassets",
    },
    {
      Option: "INCOME",
      optionvalue: "income",
    },
    {
      Option: "INDIAN OVER SEAS BANK",
      optionvalue: "indian_over_seas_bank",
    },
    {
      Option: "INDIRECT EXPENSES",
      optionvalue: "indirect_expenses",
    },
    {
      Option: "LIABLITIES",
      optionvalue: "liablities",
    },
    {
      Option: "Loans (Liability)",
      optionvalue: "loans_(liability)",
    },
    {
      Option: "PARKING FEES",
      optionvalue: "parking_fees",
    },
    {
      Option: "PERMIT CHARGES",
      optionvalue: "permit_charges",
    },
    {
      Option: "PRODAPT",
      optionvalue: "prodapt",
    },
    {
      Option: "PURCHASE",
      optionvalue: "purchase",
    },
    {
      Option: "Sales Accounts",
      optionvalue: "sales_accounts",
    },
    {
      Option: "SUNDRY CREDITORS",
      optionvalue: "sundry_creditors",
    },
    {
      Option: "SUNDRY DEBTORS",
      optionvalue: "sundry_debtors",
    },
    {
      Option: "TDS(RECEIVABLE)",
      optionvalue: "tds_(receivable)",
    },

  ];
  
  // vehicle info

  export const Vehicleinfo=[
    {
      Option: "Attached Vehicle",
      optionvalue: "attachedvahicle",
    },
    {
      Option: "Our Travels",
      optionvalue: "our_travels",
    },
  ]