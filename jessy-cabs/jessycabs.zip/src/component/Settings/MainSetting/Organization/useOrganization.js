import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

const useOrganization = () => {
    const user_id = localStorage.getItem('useridno');
    const [selectedCustomerData, setSelectedCustomerData] = useState({});
    const [rows] = useState([]);
    const [selectedImage, setSelectedImage] = useState(null);
    const [editMode, setEditMode] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [error, setError] = useState(false);
    const [success, setSuccess] = useState(false);
    const [successMessage, setSuccessMessage] = useState({});
    const [warning, setWarning] = useState(false);
    const [warningMessage] = useState({});
    const [info, setInfo] = useState(false);
    const [infoMessage, setInfoMessage] = useState({});
    const [userPermissions, setUserPermissions] = useState({});

    useEffect(() => {
        const fetchPermissions = async () => {
            try {
                const currentPageName = 'User Creation';
                const response = await axios.get(`http://localhost:8081/user-permissions/${user_id}/${currentPageName}`);
                setUserPermissions(response.data);
            } catch {
            }
        };

        fetchPermissions();
    }, [user_id]);

    const checkPagePermission = () => {
        const currentPageName = 'User Creation';
        const permissions = userPermissions || {};

        if (permissions.page_name === currentPageName) {
            return {
                read: permissions.read_permission === 1,
                new: permissions.new_permission === 1,
                modify: permissions.modify_permission === 1,
                delete: permissions.delete_permission === 1,
            };
        }

        return {
            read: false,
            new: false,
            modify: false,
            delete: false,
        };
    };

    const permissions = checkPagePermission();

    // Function to determine if a field should be read-only based on permissions
    const isFieldReadOnly = (fieldName) => {
        if (permissions.read) {
            // If user has read permission, check for other specific permissions
            if (fieldName === "delete" && !permissions.delete) {
                return true;
            }
            return false;
        }
        return true;
    };



    const [book, setBook] = useState({
        organizationname: '',
        organizationtype: '',
        addressLine1: '',
        addressLine2: '',
        city: '',
        contactPhoneNumber: '',
        contactEmail: '',
        location: '',
        website: '',
        ownershipLeadership: '',
        productsServices: '',
        marketPresence: '',
        employees: '',
        legalStructure: '',
        customerBase: '',
        partnershipsAlliances: '',
        recentNewsDevelopments: '',
        pannumber: '',
        gstnumber: '',
        socialMediaPresence: '',
        sustainabilityCSR: '',
        customerReviewsFeedback: '',
        industrySpecificDetails: '',
    });


    useEffect(() => {
        if (error) {
            const timer = setTimeout(() => {
                hidePopup();
            }, 3000);

            return () => clearTimeout(timer);
        }
    }, [error]);
    useEffect(() => {
        if (info) {
            const timer = setTimeout(() => {
                hidePopup();
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [info]);


    const handleKeyDown = useCallback(async (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            try {
                const filterValue = event.target.value;
                const response = await axios.get(`http://localhost:8081/usercreation?filter=${filterValue}`);
                const bookingDetails = response.data;
                if (Array.isArray(bookingDetails) && bookingDetails.length > 0) {
                    setBook(bookingDetails[0]);
                    setSelectedCustomerData(bookingDetails[0]);
                } else {
                }
            } catch {
            }
        }
    }, []);

    const handleAdd = async () => {
        const permissions = checkPagePermission();

        if (permissions.read && permissions.new) {
            const name = selectedCustomerData?.organizationname || book.organizationname;
            if (!name) {
                setError(true);
                setErrorMessage("fill mantatory fields");
                return;
            }
            try {
                await axios.post('http://localhost:8081/addcompany', book);
                setSuccess(true);
                setSuccessMessage("Organization Added Successfully");
            } catch {
                setError(true);
                setErrorMessage("Something went wrong");
            }
        } else {
            setInfo(true);
            setInfoMessage("You do not have permission.");
        }
    };


    const handleUpdate = async (organizationname) => {
        const permissions = checkPagePermission();

        if (permissions.read && permissions.modify) {
            try {
                const selectedCustomer = rows.find((row) => row.organizationname === organizationname);
                const updatedCustomer = { ...selectedCustomer, ...selectedCustomerData };
                const companyname = encodeURIComponent(selectedCustomerData?.organizationname) || encodeURIComponent(book.organizationname);
                const encode = companyname;
                const decode = decodeURIComponent(encode);
                await axios.put(`http://localhost:8081/companyupdate/${decode}`, updatedCustomer);
                setSuccess(true);
                setSuccessMessage("Successfully updated");
                setEditMode((prevEditMode) => !prevEditMode);
            }
            catch {
                setError(true);
                setErrorMessage("Something went wrong");
            }
        } else {
            setInfo(true);
            setInfoMessage("You do not have permission.");
        }
    };


    const handleChange = (event) => {
        const { name, value } = event.target;
        setBook((prevBook) => ({
            ...prevBook,
            [name]: value,
        }));
        setSelectedCustomerData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleUpload = () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.jpg, .jpeg, .png';
        input.onchange = handleFileChange;
        input.click();
    };
    //file upload
    const handleFileChange = async (event) => {
        const file = event.target.files[0];
        if (!file) return;
        setSelectedImage(file);
        const companyname = localStorage.getItem('usercompany');
        const formDataUpload = new FormData();
        formDataUpload.append('file', file);
        formDataUpload.append('organizationname', selectedCustomerData?.organizationname || book.organizationname || companyname);
        try {
            await axios.post('http://localhost:8081/uploads', formDataUpload);
        } catch {
        }
    };


    useEffect(() => {
        const fetchData = async () => {
            try {
                const organizationname = localStorage.getItem('usercompany');

                if (!organizationname) {
                    return;
                }
                const response = await fetch(`http://localhost:8081/get-companyimage/${organizationname}`);

                // Check if the response status is 200
                if (response.status === 200) {
                    const data = await response.json();
                    const attachedImageUrls = data.imagePaths.map(path => `http://localhost:8081/images/${path}`);
                    setSelectedImage(attachedImageUrls);
                } else {
                    const timer = setTimeout(fetchData, 2000);
                    return () => clearTimeout(timer);
                }
            } catch {
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        const fetchData = async () => {
            const encoded = localStorage.getItem('usercompany');
            localStorage.setItem('usercompanyname', encoded);
            const storedcomanyname = localStorage.getItem('usercompanyname');
            const organizationname = decodeURIComponent(storedcomanyname);
            try {
                const response = await fetch(`http://localhost:8081/organizationdata/${organizationname}`);
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                const userDataArray = await response.json();
                if (userDataArray.length > 0) {
                    setSelectedCustomerData(userDataArray[0]);
                } else {

                }
            } catch {

            }
        };

        fetchData();
    }, []);

    // const handledelete =

    // const permissions = checkPagePermission();

    // if (permissions.read && permissions.delete) {
    //     await axios.delete(`http://localhost:8081/billing/${book.tripid || selecting.tripid || selectedCustomerData.tripid || selectedCustomerDatas.tripid || formData.tripid}`);
    //     setFormData(null);
    //     setSelectedCustomerData(null);
    //     setSuccessMessage("Successfully Deleted");
    //     handleCancel();
    // } else {
    //     setInfo(true);
    //     setInfoMessage("You do not have permission.");
    // }


    const handledelete = async () => {
        const permissions = checkPagePermission();

        if (permissions.read && permissions.delete) {
            const companyname = encodeURIComponent(selectedCustomerData?.organizationname) || encodeURIComponent(book.organizationname);
            const encode = companyname;
            const decode = decodeURIComponent(encode);
            await axios.delete(`http://localhost:8081/companydelete/${decode}`);
            localStorage.removeItem("selectedImage");
            setSelectedCustomerData(null);
            setSuccess(true);
            setSuccessMessage("Successfully Deleted");
        } else {
            setInfo(true);
            setInfoMessage("You do not have permission.");
        }
    };

    const hidePopup = () => {
        setSuccess(false);
        setWarning(false);
        setInfo(false);
        setError(false);
        setErrorMessage('');
    };

    useEffect(() => {
        if (error) {
            const timer = setTimeout(() => {
                hidePopup();
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [error]);

    useEffect(() => {
        if (success) {
            const timer = setTimeout(() => {
                hidePopup();
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [success]);

    const toggleEditMode = () => {
        setEditMode((prevEditMode) => !prevEditMode);
    };

    return {
        selectedCustomerData,
        error,
        success,
        warning,
        successMessage,
        errorMessage,
        warningMessage,
        book,
        handleChange,
        isFieldReadOnly,
        handledelete,
        handleAdd,
        hidePopup,
        selectedImage,
        info,
        infoMessage,
        editMode,
        handleFileChange,
        handleUpload,
        toggleEditMode,
        handleKeyDown,
        handleUpdate
    };
};

export default useOrganization;