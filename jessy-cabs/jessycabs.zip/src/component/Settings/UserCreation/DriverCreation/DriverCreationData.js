// StationName
export const StationName = [
    {
      Option: "All Station",
      optionvalue: "allstation",
    },
    {
      Option: "Ahmedabad",
      optionvalue: "ahmedabad",
    },
    {
      Option: "Bangalore",
      optionvalue: "bangalore",
    },
    {
      Option: "Chennai",
      optionvalue: "chennai",
    },
    {
      Option: "Coimbatore",
      optionvalue: "coimbatore",
    },
    {
      Option: "Delhi",
      optionvalue: "delhi",
    },
    {
      Option: "Erode",
      optionvalue: "erode",
    },
    {
      Option: "Goa",
      optionvalue: "goa",
    },
    {
      Option: "Hyderabad",
      optionvalue: "hyderabad",
    },
    {
      Option: "Indore",
      optionvalue: "indore",
    },
    {
      Option: "Jaipur",
      optionvalue: "jaipur",
    },
    {
      Option: "Kerala",
      optionvalue: "kerala",
    },
    {
      Option: "Kolkata",
      optionvalue: "kolkata",
    },
    {
      Option: "Lucknow",
      optionvalue: "lucknow",
    },
    {
      Option: "Madurai",
      optionvalue: "madurai",
    },
    {
      Option: "Mangalore",
      optionvalue: "mangalore",
    },
    {
      Option: "Mumbai",
      optionvalue: "mumbai",
    },
    {
      Option: "Nagpur",
      optionvalue: "nagpur",
    },
    {
      Option: "New one",
      optionvalue: "new one",
    },
    {
      Option: "Pune",
      optionvalue: "pune",
    },
    {
      Option: "Tiruchi",
      optionvalue: "tiruchi",
    },
    {
      Option: "Vijayawada",
      optionvalue: "Vijayawada",
    },
  ];
  // View For
  export const ViewFor = [
    {
      Option: "Booking",
      optionvalue: "Booking",
    },
    {
      Option: "All",
      optionvalue: "All",
    },
    {
      Option: "Accounts",
      optionvalue: "Accounts",
    },
    {
      Option: "Vendor View",
      optionvalue: "Vendor-View",
    },
    {
      Option: "TripSheet",
      optionvalue: "TripSheet",
    },
  ];
  